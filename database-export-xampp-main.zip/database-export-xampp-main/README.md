# **Zero to Databases – MySQL Export**  

This repository contains an exported MySQL database from XAMPP, created as part of the **Zero to Databases** tutorial. If you're following along, you can use this `.sql` file to import the database into your own MySQL setup.  

## **Contents**  
- `my_first_db.sql` – MySQL dump file containing database structure and data.  

## **How to Import the Database**  

### **Using phpMyAdmin**  
1. Open **phpMyAdmin** by visiting: [http://localhost/phpmyadmin](http://localhost/phpmyadmin).  
2. Click on the **Import** tab.  
3. Click **Choose File** and select `my_first_db.sql`.  
4. Click **Go** to start the import.  

### **Using MySQL Command Line**  
1. Open a terminal or command prompt.  
2. Navigate to your MySQL `bin` directory:  
   ```sh
   cd C:\xampp\mysql\bin
   ```  
3. Log in to MySQL:  
   ```sh
   mysql -u root -p
   ```  
4. Create a new database (if it doesn’t exist):  
   ```sql
   CREATE DATABASE my_first_db;
   ```  
5. Import the SQL file:  
   ```sh
   mysql -u root -p my_first_db < path/to/my_first_db.sql
   ```  

## **License**  
Feel free to use and modify this database for learning purposes!
